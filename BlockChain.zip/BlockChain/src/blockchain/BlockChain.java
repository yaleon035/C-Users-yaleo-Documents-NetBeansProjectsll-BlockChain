/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockchain;

import java.util.ArrayList;

/**
 *
 * @author yaleo
 */
public class BlockChain {

    public ArrayList<Block> blockChain = new ArrayList<>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String[] transaction = {"jhon gave Joe 3 bitcoins", "Oneil send 45 bitcoins to Joe"};
        Block block1 = new Block(0, transaction);
        String[] transaction2 = {"John gave Joe 133 bitcoins", "Oneil send 450 bitcoins to Joe"};
        Block block2 = new Block(0, transaction2);
        String[] transaction3 = {"John gave Joe 3 bitcoins", "Oneil send 4 bitcoins to Joe"};
        Block block3 = new Block(0, transaction3);

        System.out.print("blocChain hash 1:");
        System.out.println(block1.getBlockHash());
        System.out.println();
        System.out.print("blocChain hash 2:");
        System.out.println(block2.getBlockHash());
        System.out.println();
        System.out.print("blocChain hash 3:");
        System.out.println(block3.getBlockHash());
        System.out.println();
    }

}
